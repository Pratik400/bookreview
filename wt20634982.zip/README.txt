
//////////////////////////////////////////////////
/////   LOGIN CREDINTIALS TO ADD BOOK   /////////
////////////////////////////////////////////////

   ----  USERNAME  ---->   wt
   ----  PASSWORD  ---->   cdms

////////////////////////////////////////////////
///////////////////////////////////////////////
//////////////////////////////////////////////


!!!!! CLICK ON THE "BOOKBUDDY" LOGO TO TOGGLE CSS FILE



1. Basic Webpages and Content. (6 marks)
    - Homepage
    - About
    - Book Table
        -- List All Books
        -- Search books by Name, ID or Author
    - View book
    - Add Book
    - Contact


2. Cascading Style Sheets. 
    - assets/css/style2.css
    - assets/css/style1.css


3. Forms, Queries, and Data Collection. 
    - Login Form (  username: wt , password: cdms  )
    - Add book form with author


4. Exploratory Challenges.
    - Use of @include to manage layouts and reduce HTML code duplication
    - Responsive Navbar
    - Small animations on buttons
    - Dynamic Add/remove author when submitting a new book
    - Inserting in to 3 tables (book, author and authorship) from a single form
    - AJAX Search
    - Pseudo code css for Buttons and Page header
    - Storing sessions to manage user logins
    - Using localstorage to store the css variable 


5. Overall Quality and Professionalism. 
    - Responsive Design
    - Flexible and Scalable css
    - Sectioned HTML for easy readabillity
    - Simple, Modern and Minimalistic design 